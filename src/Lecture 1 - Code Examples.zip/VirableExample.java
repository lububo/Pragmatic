

public class VirableExample {
	
	public static void main(String[] args) {
		
		int age = 18;
		System.out.println(age);
		age = 20;
		System.out.println(age);

		age = age + 1;
		age = age - 1;
		age = age / 2;
		System.out.println(age);
		
		double pi = 3.14;
		pi = pi + 100.2;
		
		char plus = '+';
		boolean isMonday = false;
	}
	
}
